import java.util.ArrayList;
import java.util.Iterator;
/**Class: Rooms
 * @author Jinyi Zhen
 * @version 1.0
 * Course: ITEC 3860 Spring 2024
 * Written: January 24, 2025
 *
 * This class – This class is process about rooms information.
 */
public class Rooms {
    private String roomID;
    private String roomName;
    private String roomDescription;
    private String roomExitDescription;
    private boolean visited;
    ArrayList<Rooms> rooms = new ArrayList<>();
    private String currentRoomID;

    /** Method: Rooms
     * the process to add a Rooms type object.
     * @param roomID a string for room's ID
     * @param roomName a string for room's name
     * @param roomDescription a string for room's description
     * @param roomExitDescription a string for room's exit description
     * not return
     */
    public Rooms(String roomID, String roomName, String roomDescription, String roomExitDescription) {
        setRoomID(roomID);
        setRoomName(roomName);
        String[] description = roomDescription.split("-");
        String outputDescription = "";
        for(String line : description){
            outputDescription += line;
            outputDescription += '\n';
        }
        setRoomDescription(outputDescription);
        setRoomExitDescription(roomExitDescription);
        setVisited(false);
    }

    /** Method: Rooms
     * the process to build each room's initial data.
     * not param
     * not return
     */
    public Rooms(){
        FileManage fileManage = new FileManage();
        rooms = fileManage.readRooms();
        setCurrentRoomID("1");
    }

    /** Method: getRoomID
     * the process to get room ID
     * not param
     * @return roomID
     */
    public String getRoomID() {
        return roomID;
    }

    /** Method: setRoomID
     * the process to set room ID
     * @param roomID the room ID need to set
     * not return
     */
    public void setRoomID(String roomID) {
        this.roomID = roomID;
    }

    /** Method: getRoomName
     * the process to get room name
     * not param
     * @return room name
     */
    public String getRoomName() {
        return roomName;
    }

    /** Method: setRoomName
     * the process to set room name
     * @param roomName the room name need to set
     * not return
     */
    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    /** Method: getRoomDescription
     * the process to get room description information
     * not param
     * @return room description information
     */
    public String getRoomDescription() {
        return roomDescription;
    }

    /** Method: setRoomDescription
     * the process to set room description
     * @param roomDescription the room description need to set
     * not return
     */
    public void setRoomDescription(String roomDescription) {
        this.roomDescription = roomDescription;
    }

    /** Method: getRoomExitDescription
     * the process to get exit description information
     * not param
     * @return exit description information
     */
    public String getRoomExitDescription() {
        return roomExitDescription;
    }

    /** Method: setRoomExitDescription
     * the process to set room exit description
     * @param roomExitDescription the room exit description need to set
     * not return
     */
    public void setRoomExitDescription(String roomExitDescription) {
        this.roomExitDescription = roomExitDescription;
    }

    /** Method: isVisited
     * the process to get isVisited state
     * not param
     * @return visit state
     */
    public boolean isVisited() {
        return visited;
    }

    /** Method: setVisited
     * the process to set visited state
     * @param visited change room visit state
     * not return
     */
    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    /** Method: getCurrentRoomID
     * the process to get current room ID
     * not param
     * @return current room ID
     */
    public String getCurrentRoomID() {
        return currentRoomID;
    }

    /** Method: setCurrentRoomID
     * the process to set current room ID
     * @param currentRoomID the current room ID want to set
     * not return
     */
    public void setCurrentRoomID(String currentRoomID) {
        this.currentRoomID = currentRoomID;
    }

    /** Method: printAllRooms
     * the process to print all rooms information.
     * not param
     * @return output - a string including all room information need to print
     */
    public String printAllRooms(){
        ArrayList<Rooms> rooms;
        FileManage fileManage = new FileManage();
        rooms = fileManage.readRooms();
        Iterator <Rooms> iterator = rooms.iterator();
        String output = "";
        while(iterator.hasNext()){
            Rooms room = iterator.next();
            output += "ID = " + room.getRoomID() + ", name = " + room.getRoomName() + '\n';
            output += "Description" + '\n';
            output += room.getRoomDescription();
            output += "exits\n";
            output += room.getRoomExitDescription() + '\n';
            output += '\n';
        }
        return output;
    }

    /** Method: moveRoom
     * the process to call direction check and return an information about invalid or a room information after moved
     * @param direction a direction from player enter
     * @return output - a string return invalid information or when moved after room information
     */
    public String moveRoom(String direction){
        Exits exits = new Exits();
        String checkExit = exits.checkMove(direction, getCurrentRoomID());
        if(checkExit.equals("Invalid direction entered")){
            return checkExit;
        }
        else{
            Iterator <Rooms> iterator = rooms.iterator();
            String output = "";
            while(iterator.hasNext()){
                Rooms room = iterator.next();
                if(room.getRoomID().equals(checkExit)){
                    setCurrentRoomID(room.getRoomID());
                    if (room.isVisited()) {
                        output += room.getRoomName() + " Visited\n";
                    } else {
                        output += room.getRoomName() + " Not visited\n";
                        room.setVisited(true);
                    }
                    output += room.getRoomDescription();
                    output += room.getRoomExitDescription();
                    return output;
                }
            }
        }
        return "Failed to check move.";
    }

    /** Method: printRoom
     * the process to search information in a special room.
     * @param  roomID a string for room's ID
     * @return output - a special room information
     */
    public String printRoom(String roomID){
        Iterator <Rooms> iterator = rooms.iterator();
        String output = "";
        while(iterator.hasNext()) {
            Rooms room = iterator.next();
            if (room.getRoomID().equals(roomID)) {
                if (room.isVisited()) {
                    output += room.getRoomName() + " Visited\n";
                } else {
                    output += room.getRoomName() + " Not visited\n";
                    room.setVisited(true);
                }
                output += room.getRoomDescription();
                output += room.getRoomExitDescription() + '\n';
                return output;
            }
        }
        return "Failed to look " + roomID + " information.";
    }

    /** Method: lookCommand
     * the process when player typed 'look' and return a string about want look's room information.
     * @param roomID a string for room's ID
     * @return output - a string for special want to look's room information or invalid information
     */
    public String lookCommand(String roomID){
        Iterator <Rooms> iterator = rooms.iterator();
        String output = "Look RoomID: " + roomID + ":\n";
        while(iterator.hasNext()) {
            Rooms room = iterator.next();
            if (room.getRoomID().equals(roomID)) {
                if (room.isVisited()) {
                    output += room.getRoomName() + " Visited\n";
                } else {
                    output += room.getRoomName() + " Not visited\n";
                    room.setVisited(true);
                }
                output += room.getRoomDescription();
                output += room.getRoomExitDescription();
                return output;
            }
        }
        return "Invalid roomID entered (You should enter a number 1-6)";
    }
}
