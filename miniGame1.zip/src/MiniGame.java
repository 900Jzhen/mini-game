import java.util.Scanner;
/**Class: MiniGame
 * @author Jinyi Zhen
 * @version 1.0
 * Course: ITEC 3860 Spring 2024
 * Written: January 24, 2025
 *
 * This class – This class is process for mini-game display and process.
 */
public class MiniGame {
    /** Method: start
     * the process when run button check and the process for game.
     * @param args args
     * not return
     */
    public static void main(String[] args){
        Rooms rooms = new Rooms();
        System.out.println();
        System.out.println("Rooms");
        System.out.println(rooms.printAllRooms());
        //introduction game
        System.out.println("Welcome to my adventure game. You will proceed through rooms based upon your entries.\n" +
                "You can navigate by using the entire direction or just the first letter.\n" +
                "You can view a room using the 'Look' command.\n" +
                "You can enter x(X) to quit the game\n");
        System.out.println();
        System.out.println(rooms.printRoom("1"));
        System.out.println("What would you like to do?");
        Scanner scanner = new Scanner(System.in);
        String direction = scanner.next();
        while(!direction.equalsIgnoreCase("x")){
            if(direction.equalsIgnoreCase("look")){
                System.out.println("Which room you want to look? (room number 1-6)");
                String roomID = scanner.next();
                System.out.println(rooms.lookCommand(roomID));
            }
            else {
                System.out.println(rooms.moveRoom(direction));
            }
            System.out.println();
            System.out.println("What would you like to do?");
            direction = scanner.next();
        }
        System.out.println("Exit");
        System.out.println();
        System.out.print("Thank you for playing my Game.");
    }
}