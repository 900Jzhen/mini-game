import java.util.ArrayList;
import java.util.Iterator;
/**Class: Exits
 * @author Jinyi Zhen
 * @version 1.0
 * Course: ITEC 3860 Spring 2024
 * Written: January 24, 2025
 *
 * This class – This class is process about exit information.
 */
public class Exits {
    private String roomID;
    private String direction;
    private String roomExitID;
    ArrayList<Exits> exits = new ArrayList<>();

    /** Method: Exits
     * the process to add an exit type object.
     * @param roomID a string for room's ID
     * @param direction a string for direction
     * @param roomExitID a string for room's ID when moved direction after
     * not return
     */
    public Exits(String roomID, String direction, String roomExitID) {
        setRoomID(roomID);
        setDirection(direction);
        setRoomExitID(roomExitID);
    }

    /** Method: Exits
     * the process to build each exit's initial data.
     * not param
     * not return
     */
    public Exits() {
        FileManage fileManage = new FileManage();
        exits = fileManage.readExits();
    }

    /** Method: getRoomID
     * the process to get room ID
     * not param
     * @return roomID
     */
    public String getRoomID() {
        return roomID;
    }

    /** Method: setRoomID
     * the process to set room ID
     * @param roomID the room ID need to set
     * not return
     */
    public void setRoomID(String roomID) {
        this.roomID = roomID;
    }

    /** Method: getDirection
     * the process to get direction
     * not param
     * @return direction
     */
    public String getDirection() {
        return direction;
    }

    /** Method: setDirection
     * the process to set direction
     * @param direction the direction need to set
     * not return
     */
    public void setDirection(String direction) {
        this.direction = direction;
    }

    /** Method: getRoomExitID
     * the process to get room exit ID
     * not param
     * @return room exit ID
     */
    public String getRoomExitID() {
        return roomExitID;
    }

    /** Method: setRoomExitID
     * the process to set when moved after room ID
     * @param roomExitID the room ID when moved after need to set
     * not return
     */
    public void setRoomExitID(String roomExitID) {
        this.roomExitID = roomExitID;
    }

    /** Method: checkMove
     * the process to check exit direction if valid.
     * @param direction a string for exit direction
     * @param currentRoomID a string for current room ID
     * @return a string for invalid or a room ID after moved exit direction.
     */
    public String checkMove(String direction, String currentRoomID) {
        if(direction.equalsIgnoreCase("w")||direction.equalsIgnoreCase("west")){
            direction = "west";
        }
        else if(direction.equalsIgnoreCase("e")||direction.equalsIgnoreCase("east")){
            direction = "east";
        }
        else if(direction.equalsIgnoreCase("s")||direction.equalsIgnoreCase("south")){
            direction = "south";
        }
        else if (direction.equalsIgnoreCase("n")||direction.equalsIgnoreCase("north")){
            direction = "north";
        }
        else{
            return "Invalid direction entered";
        }
        Iterator<Exits> iterator = exits.iterator();
        while(iterator.hasNext()){
            Exits exit = iterator.next();
            if(exit.getRoomID().equals(currentRoomID) && exit.getDirection().equalsIgnoreCase(direction)){
                return exit.getRoomExitID();
            }
        }
        return "Invalid direction entered";
    }
}
