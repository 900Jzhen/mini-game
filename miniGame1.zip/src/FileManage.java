import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**Class: FileManage
 * @author Jinyi Zhen
 * @version 1.0
 * Course: ITEC 3860 Spring 2024
 * Written: January 24, 2025
 *
 * This class – This class is process about read all rooms or exits information from file.
 */
public class FileManage {
    /** Method: readRooms
     * the process to read all rooms information
     * not param
     * @return rooms - an arraylist in Rooms type about all rooms information.
     */
    public ArrayList<Rooms> readRooms(){
        ArrayList<Rooms> rooms = new ArrayList<>();
        String roomID;
        String roomName;
        String roomDescription;
        String roomExitDescription;
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader("Rooms.txt"));
            String check = "";
            while ((check = bufferedReader.readLine()) != null){
                roomID = check;
                check = bufferedReader.readLine();
                roomName = check;
                check = bufferedReader.readLine();
                roomDescription = check;
                check = bufferedReader.readLine();
                roomExitDescription = check;
                rooms.add(new Rooms(roomID, roomName, roomDescription, roomExitDescription));
            }
        }catch (IOException e){
            System.out.println("Fail to read rooms file." + e.getMessage());
        }
        return rooms;
    }

    /** Method: readExits
     * the process to read all exits information.
     * not param
     * @return exits - an arrayList in Exits type about all exits information.
     */
    public ArrayList<Exits> readExits(){
        ArrayList<Exits> exits = new ArrayList<>();
        String roomID;
        String direction;
        String roomExitID;
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader("Exits.txt"));
            String check = "";
            while ((check = bufferedReader.readLine()) != null){
                roomID = check;
                check = bufferedReader.readLine();
                direction = check;
                check = bufferedReader.readLine();
                roomExitID = check;
                exits.add(new Exits(roomID,direction,roomExitID));
            }
        }catch (IOException e){
            System.out.println("Fail to read exits file." + e.getMessage());
        }
        return exits;
    }


}
